﻿using System;

namespace MyApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Math.Abs(-4.7));
            Console.WriteLine(Math.Abs(-15.89));
            Console.WriteLine(Math.Round(9.99));
            Console.WriteLine(Math.Round(159.456));
            Console.WriteLine(Math.Max(8, 16));
            Console.WriteLine(Math.Min(56, 89));
            Console.WriteLine(Math.Sqrt(64));
        }
    }

}