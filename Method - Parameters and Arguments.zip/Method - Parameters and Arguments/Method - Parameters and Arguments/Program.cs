﻿using System;


namespace MyApplication
{
    class Program
    {

        static void MyMethod(string fname, string lname)
        {
            Console.WriteLine(fname + " " + lname);
        }




            static void Main(string[] args)
            {
                MyMethod("Donald", " Tramp");
                MyMethod("Melania", " McDonald");
                MyMethod("Baron", " Doe");

            }

        
    }
}
