using System;
using System.Drawing;
using System.Windows.Forms;

    namespace Project1
    {
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightCyan;
            button1.ForeColor = Color.DarkViolet;
            button1.BackColor = Color.FromArgb(255, 200, 100);
            button1.ForeColor = Color.DarkSalmon;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightPink;
            button1.ForeColor = Color.DarkTurquoise;
            MessageBox.Show("button clicked");
        }

        

        
    }
}
