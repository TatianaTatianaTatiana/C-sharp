﻿using System;

namespace MyApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 59;
            Console.WriteLine(x);

            int a = 25;
            a += 7;
            Console.WriteLine(a);

            int b = 9;
            b -= 3;
            Console.WriteLine(b);

            int c = 5;
            c *= 4;
            Console.WriteLine(c);

            double v = 16;
            v /= 5;
            Console.WriteLine(v);

            int d = 11;
            d %= 3;
            Console.WriteLine(d);


       
        }
    }

}