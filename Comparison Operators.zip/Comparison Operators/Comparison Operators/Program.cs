﻿using System;

namespace MyApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 9;
            int y = 6;
            Console.WriteLine(x > y);

            int a = 5;
            int b = 2;
            Console.WriteLine(a == b);

            int s = 3;
            int g = 3;
            Console.WriteLine(s != g);

            int h = 24;
            int j = 12;
            Console.WriteLine(h > j);

            int w = 5;
            int p = 3;
            Console.WriteLine(p < w);

            int d = 8;
            int n = 7;
            Console.WriteLine(d >= n);

            int k = 49;
            int l = 27;
            Console.WriteLine(k <= l);

             

        }
    }
}

