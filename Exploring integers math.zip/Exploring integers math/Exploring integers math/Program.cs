﻿using System;

namespace NumbersInCsharp
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 18;
            int b = 6;
            int sum = a + b;
            Console.WriteLine(sum);
            int c1 = a - b;
            Console.WriteLine(c1);
            int c2 = a * b;
            Console.WriteLine(c2);
            int c3 = a / b;
            Console.WriteLine(c3);
            int c4 = a + b - 12 * 17;
            Console.WriteLine(c4);
            int a1 = 5;
            int b1 = 4;
            int c5 = 2;
            int d = a + b * c5;
            Console.WriteLine(d);
            int f = (a1 + b1) * sum;
            Console.WriteLine(d);
            int d1 = (a + b) - 6 * sum + (12 * 4) / 3 + 12;
            Console.WriteLine(d1);
            int e = 7;
            int j = 4;
            int g = 3;
            int h = (e - j) + 9 * - (j / g);
            Console.WriteLine(h);


        }

    }


}



 
 





        
