﻿using System;

namespace MyApplication
{
    class Program
{
    static void Main(string[] args)
    {
        int x = 5;
        Console.WriteLine(x > 3 && x < 10);

            int a = 15;
            Console.WriteLine(a > 4 && a < 12);

            int b = 5;
            Console.WriteLine(b > 3 || b < 4);

            int f = 5;
            Console.WriteLine(!(f > 3 && f < 10));
            Console.WriteLine(!(f > 3 || f < 10));
    }
}

}



