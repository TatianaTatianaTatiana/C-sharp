﻿using System;


namespace MyApplication
{
    class Program
    {
        /*static int MyMethod(int x, int y)
        {
            return x + y;
        }


        static void Main(string[] args)
        {

            int z = MyMethod(5, 3);
            Console.WriteLine("The amount is " + z);*/



            static int MyMethod(int a, int b)
            {
                return a / b;
            }


            static void Main(string[] args)
            {

                int c = MyMethod(15, 5);
                Console.WriteLine("The amount is " + c);
            }
        
    }
}