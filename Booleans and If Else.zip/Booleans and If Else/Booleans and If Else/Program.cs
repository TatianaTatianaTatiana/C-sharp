﻿using System;
using System.ComponentModel.Design;

namespace MyApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10;
            int y = 6;
            Console.WriteLine(y > x);
            Console.WriteLine(10 > 6);
            Console.WriteLine(x == 10);

            bool isKatiabeautifull = true;
            bool isKatialiar = false;
            Console.WriteLine(isKatialiar);
            Console.WriteLine(isKatiabeautifull);

            int myAge = 45;
            int votingAge = 18;

            if (myAge >= votingAge)
            {
                Console.WriteLine("Old enough to vote!");
            }
            else
            {
                Console.WriteLine("Not old enough to vote");
            }
            if (20 > 18)
            {
                Console.WriteLine("20 is greater than 18");
            }

            int time = 20;
            if (time < 18)
            {
                Console.WriteLine("Good day.");

            }
            else
            {
                Console.WriteLine("Good evening.");
            }

            int time1 = 8;
            if (time1 < 10)
            {
                Console.WriteLine("Good morning.");
            }
            else if (time1 < 20)
                {
                Console.WriteLine("Good day.");
            }
            else
            {
                Console.WriteLine("Good evening.");
            }

            int time2 = 19;
            string result = (time2 >
                18) ? "Good day." : "Good evening.";
            Console.WriteLine(result);

                
            







        }
    }
}