﻿using System;
using System.Collections.Generic;



class FlashcardQuiz
{
    static void Main()
    {
        Console.WriteLine("Welcome to the Flashcard Quiz!");
        Console.WriteLine("Type your answer and press Enter.\n");

        // Create flashcards using Dictionary
        Dictionary<string, string> flashcards = new Dictionary<string, string>()
        {
            {"What is the capital of France?", "Paris"},
            {"What is 5 + 3?", "8"},
            {"What planet is known as the Red Planet?", "Mars"},
            {"Who wrote 'Romeo and Juliet'?", "Shakespeare"},
            {"What is the square root of 64?", "8"}
        };

        int score = 0; // Initialize user's score to 0

        // Loop through each flashcard in the dictionary

        foreach (KeyValuePair<string, string> card in flashcards)
        {
            Console.WriteLine(card.Key);
            Console.Write("Your answer: ");
            string userAnswer = Console.ReadLine().Trim();

            if (userAnswer.Equals(card.Value, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Correct!\n");
                score++;
            }
            else
            {
                Console.WriteLine($"Incorrect. The correct answer is: {card.Value}\n");
            }
        }

        Console.WriteLine($"Quiz Complete! You got {score} out of {flashcards.Count} right.");
    }
}
