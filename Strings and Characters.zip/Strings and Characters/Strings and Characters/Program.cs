﻿using System;

class StringCompare
{
    static void Main(string[] args)
    {
        var string1 = "hello";
        var string2 = "good bye";
        var string3 = "Happy Birthday";
        var string4 = "happy birthday";

        Console.WriteLine($"string1 = \"{string1}\"" +
            $"\nstring2 = \"{string2}\"" +
            $"\nstring3 = \"{string3}\"" +
            $"\nstring4 = \"{string4}\"\n");
    








    
    
    
       
            char[] characterArray = { 'b', 'i', 'r', 't', 'h', ' ', 'd', 'a', 'y' };
            var originalString = "Welcome to C# programming!";
            var string5 = originalString;
            var string6 = new string(characterArray);
            var string7 = new string(characterArray, 6, 3);
            var string8 = new string('C', 5);
            

            Console.WriteLine($"string1 = \"{string1}\"\n" +
                $"string6 = \"{string2}\"\n" +
                $"string7 = \"{string3}\"\n" +
                $"string8" +
                $" = \"{string4}\"\n");


           

            
                string txt = "I love studying C#";

                Console.WriteLine(txt.ToUpper());
                Console.WriteLine(txt.ToLower());

                string firstName = "Katia";
                string lastName = "Rotaru";
                string name = $"My name is: {firstName}  {lastName}";
                Console.WriteLine(name);
                Console.WriteLine(firstName[0]);
                Console.WriteLine(lastName[5]);
                Console.WriteLine(firstName.IndexOf("t"));
                bool isKatiaBeautiful = true;
                bool isKatiaLiar = false;
                Console.WriteLine(isKatiaBeautiful);
                Console.WriteLine(isKatiaLiar);

                string txt1 = "12365478965";
                Console.WriteLine("The lenght of the text is:" + txt1.Length);

                string firstName1 = "Tatiana ";
                string lastName1 = "Moldovan";
                string name1 = string.Concat(firstName1, lastName1);
                Console.WriteLine(name1);
                string name2 = $"My full name is: {firstName1} {lastName1}";
                Console.WriteLine(name2);
                string myString1 = "college";
                Console.WriteLine(myString1[3]);


            
        }
    }



    







 